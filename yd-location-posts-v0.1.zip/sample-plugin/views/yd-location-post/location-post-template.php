<script id="yd-location-post-template" type="text/x-handlebars-template">
	<h4>{{post_title}}</h4>
	<p>{{{post_content}}}</p>
</script>